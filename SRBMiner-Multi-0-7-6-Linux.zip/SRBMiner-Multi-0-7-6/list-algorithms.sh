#!/bin/sh
./SRBMiner-MULTI --list-algorithms
